#pragma once
#include<list>
#include<iostream>
#include<queue>
#include<stack>
using namespace std;

struct state
{
	int CurrentRow, CurrentCol;
	list<list<char>> text;
	list<char>::iterator citr;
	list<list<char>>::iterator ritr;
};
class CurrentFile
{

private:

	int CurrentRow, CurrentCol;
	list<list<char>> text;
	list<char>::iterator citr;
	list<list<char>>::iterator ritr;
	//undo 
	//Redo
public:
	CurrentFile()
	{
		CurrentRow = 0;
		CurrentCol = 0;
		text.push_back(list<char>());
		ritr = text.begin();
		(*ritr).push_back(' ');
		citr = (* ritr).begin();
	}
	void InsertText(char ch)
	{
		(*ritr).push_back(ch);
		CurrentCol++;
	}
	void PrintFile()
	{
		list<list<char>>::iterator Temp=text.begin();

		for (Temp = text.begin();Temp!= ritr; ++Temp)
		{
			list<char>::iterator Col;

			for (Col = Temp;*Col!='\n'; Col++)
			{
				cout << *Col;
			}
			cout << endl;
		}
	}
};


