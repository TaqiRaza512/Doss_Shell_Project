#include<iostream>
#include"NotePad.h"
#include"CurrentFile.h"
#include"Doss.h"
#include"Tree.h"
#include"File.h"
#include"Folders.h"

using namespace std;
int main()
{
	CurrentFile Fp;
	Fp.InsertText('b');
	Fp.InsertText('a');
	Fp.InsertText('q');
	Fp.InsertText('i');
	Fp.InsertText('r');
	Fp.InsertText('\n');
	Fp.InsertText('t');
	Fp.InsertText('a');
	Fp.InsertText('q');
	Fp.InsertText('i');

	cout << endl;
	Fp.PrintFile();


	//Doss D;
	//D.Profile();

	//while (true)
	//{
	//	D.InputCommand();
	//}
}