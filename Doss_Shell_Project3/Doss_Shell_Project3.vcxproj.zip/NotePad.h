#pragma once
#include<iostream>
#include<list>
using namespace std;
class NotePad
{
private:


public:


};