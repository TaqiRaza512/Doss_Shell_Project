#include "Tree.h"
#include<string.h>
#include"File.h"
#include"Folders.h"
#include<iostream>
using namespace std;
Tree::Tree()
{
	Root = CurrentFolder=new Folders("C:",nullptr,"C:\\");
	CurrentFolder->InsertSubFolder("Pakistan");
	Folders*Pakistan=CurrentFolder->SubFolders.front();
	Pakistan->InsertSubFolder("Punjab");
	Pakistan->InsertSubFolder("Sindh");
	Pakistan->InsertSubFolder("Balochistan");
	Pakistan->InsertSubFolder("KPK");
}
void Tree::GoThroughAllTree(Folders *CurrentFolder)
{
	if (CurrentFolder->SubFolders.size()==0)
	{
		return;
	}
	for (auto t=CurrentFolder->SubFolders.begin(); t != CurrentFolder->SubFolders.end();t++)
	{
		GoThroughAllTree(*t);
		cout << (*t)->Name << " ";
	}
	cout << endl;
}
void Tree::GoThroughAllTree()
{
	GoThroughAllTree(Root);
}
